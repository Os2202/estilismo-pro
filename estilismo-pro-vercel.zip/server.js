const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

// Configuración del servidor
const PORT_HTTP = 8080;
const PORT_HTTPS = 8443;

// Función para obtener el tipo MIME
function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html',
    '.js': 'application/javascript',
    '.css': 'text/css',
    '.json': 'application/json',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.wav': 'audio/wav',
    '.mp4': 'video/mp4',
    '.woff': 'application/font-woff',
    '.ttf': 'application/font-ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.otf': 'application/font-otf',
    '.wasm': 'application/wasm'
  };
  return mimeTypes[ext] || 'application/octet-stream';
}

// Función para servir archivos
function serveFile(req, res) {
  let filePath = '.' + req.url;
  if (filePath === './') {
    filePath = './estilismo_app.html';
  }

  const extname = String(path.extname(filePath)).toLowerCase();
  const contentType = getMimeType(filePath);

  fs.readFile(filePath, (error, content) => {
    if (error) {
      if (error.code === 'ENOENT') {
        res.writeHead(404, { 'Content-Type': 'text/html' });
        res.end('<h1>404 - Archivo no encontrado</h1>', 'utf-8');
      } else {
        res.writeHead(500);
        res.end('Error del servidor: ' + error.code + ' ..\n');
      }
    } else {
      res.writeHead(200, { 
        'Content-Type': contentType,
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
      });
      res.end(content, 'utf-8');
    }
  });
}

// Función para generar certificados SSL simples
function generateSSLCertificates() {
  if (!fs.existsSync('server_secure.crt') || !fs.existsSync('server_secure.key')) {
    console.log('🔧 Generando certificados SSL...');
    
    const simpleCert = `-----BEGIN CERTIFICATE-----
MIIBkTCB+wIJAMHGxIuexjlzMA0GCSqGSIb3DQEBCwUAMBQxEjAQBgNVBAMMCWxv
Y2FsaG9zdDAeFw0yNDA2MzAyMDAwMDBaFw0yNTA2MzAyMDAwMDBaMBQxEjAQBgNV
BAMMCWxvY2FsaG9zdDBcMA0GCSqGSIb3DQEBAQUAA0sAMEgCQQCzjTYFp2lEe8sV
tQ1wUxW3oTt5Z3Ky8v7bVcXq1mNrLtGhJKl1ZmF4sF6hKpVq8fTyYnWqSdLv1zG
P5LqW7pF0j3R1nOwIDAQABMA0GCSqGSIb3DQEBCwUAA0EAkJ7Q1wF8yTc9Zl2o3
T6vXq4F1mN8Y2bH3vD7jKl9wP8fQr1sN2kL5vW8tR6pE3qY7nF4mX1zG9cV2hL
-----END CERTIFICATE-----`;
    
    const simpleKey = `-----BEGIN PRIVATE KEY-----
MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAs402BaepRHvLFbUN
cFMVt6E7eWdysvL+21XF6tZjay7RoSSpdWZheLBeoSqVavH08mJ1qknS79cxj+S6
lu6RdI90dTsAAwEAAQJBAJy9lNZYCdq8Lm1jGj1sF9Wt7YvQ6nK3s2F1oR9X4tZ
P6wL5vN8kR2mT1qS7fE9yX4vZ1cH2nL8qR6pS5wF9XtECIQDYqS7wR9t2nF1mL
P3vQ6tZ2kH4vW8rS1yX9cF7nL8qRwIhAM2F1oR9X4tZP6wL5vN8kR2mT1qS7fE
9yX4vZ1cH2nL8AiEAyX9cF7nL8qRwDYqS7wR9t2nF1mLP3vQ6tZ2kH4vW8rS1y
X9cCIQDJf1wXucvyqHANipLvBH23acXWYs/e9Dq1naQfi9bytLXJf1wAiB7vD7
jKl9wP8fQr1sN2kL5vW8tR6pE3qY7nF4mX1zG9cV2hL8qRwDYqS7wR9t2nF1mL
P5LqW7pF0j3R1nOwIDAQAB
-----END PRIVATE KEY-----`;

    fs.writeFileSync('server_secure.crt', simpleCert);
    fs.writeFileSync('server_secure.key', simpleKey);
    
    console.log('✅ Certificados SSL generados');
    return true;
  }
  return true;
}

// Obtener la IP local
function getLocalIP() {
  const { networkInterfaces } = require('os');
  const nets = networkInterfaces();
  const results = {};

  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        if (!results[name]) {
          results[name] = [];
        }
        results[name].push(net.address);
      }
    }
  }

  // Retornar la primera IP encontrada
  for (const name of Object.keys(results)) {
    if (results[name].length > 0) {
      return results[name][0];
    }
  }
  
  return '192.168.0.21'; // IP por defecto si no se encuentra
}

// Generar certificados SSL
generateSSLCertificates();

// Configuración SSL
const options = {
  key: fs.readFileSync('server_secure.key'),
  cert: fs.readFileSync('server_secure.crt')
};

// Crear servidor HTTPS
const httpsServer = https.createServer(options, serveFile);

// Crear servidor HTTP que redirige a HTTPS
const httpServer = http.createServer((req, res) => {
  const host = req.headers.host.split(':')[0];
  const httpsUrl = `https://${host}:${PORT_HTTPS}${req.url}`;
  
  res.writeHead(301, { 'Location': httpsUrl });
  res.end();
});

// Iniciar servidores
const localIP = getLocalIP();

httpServer.listen(PORT_HTTP, '0.0.0.0', () => {
  console.log('🌐 Servidor HTTP iniciado');
  console.log(`   Local:    http://localhost:${PORT_HTTP}`);
  console.log(`   Red:      http://${localIP}:${PORT_HTTP}`);
});

httpsServer.listen(PORT_HTTPS, '0.0.0.0', () => {
  console.log('🔒 Servidor HTTPS iniciado');
  console.log(`   Local:    https://localhost:${PORT_HTTPS}`);
  console.log(`   Red:      https://${localIP}:${PORT_HTTPS}`);
  console.log('');
  console.log('📱 Para acceder desde tu teléfono:');
  console.log(`   1. Conecta tu teléfono a la misma red WiFi`);
  console.log(`   2. Abre: https://${localIP}:${PORT_HTTPS}`);
  console.log(`   3. Acepta el certificado de seguridad (aviso SSL)`);
  console.log(`   4. ¡El escáner de códigos funcionará!`);
  console.log('');
  console.log('⚠️  IMPORTANTE: Acepta el certificado SSL cuando tu navegador lo solicite');
  console.log('   El certificado es autofirmado y seguro para desarrollo local.');
});

// Manejo de errores
process.on('uncaughtException', (err) => {
  console.error('Error no capturado:', err);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Promesa rechazada no manejada:', reason);
});
