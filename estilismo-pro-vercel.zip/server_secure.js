const https = require('https');
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const rateLimit = require('express-rate-limit');
const helmet = require('helmet');

// Configuración del servidor
const PORT_HTTP = 8080;
const PORT_HTTPS = 8443;

// Lista blanca de dominios permitidos (CORS seguro)
const ALLOWED_ORIGINS = [
  'https://localhost:8443',
  'https://127.0.0.1:8443'
];

// Función para validar y sanitizar rutas (prevenir Path Traversal)
function sanitizePath(requestPath) {
  // Remover caracteres peligrosos
  const sanitized = requestPath.replace(/[<>:"|?*]/g, '');
  
  // Resolver el path y verificar que no escape del directorio actual
  const resolvedPath = path.resolve('.', sanitized);
  const currentDir = path.resolve('.');
  
  if (!resolvedPath.startsWith(currentDir)) {
    throw new Error('Path traversal attempt detected');
  }
  
  return sanitized;
}

// Función para obtener el tipo MIME de forma segura
function getMimeType(filePath) {
  const ext = path.extname(filePath).toLowerCase();
  const mimeTypes = {
    '.html': 'text/html; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf',
    '.eot': 'application/vnd.ms-fontobject',
    '.otf': 'font/otf'
  };
  return mimeTypes[ext] || 'application/octet-stream';
}

// Función para generar nonce único para CSP
function getNonce() {
  return crypto.randomBytes(16).toString('base64');
}

// Headers de seguridad mejorados
function getSecurityHeaders(origin) {
  const isAllowedOrigin = ALLOWED_ORIGINS.includes(origin) || origin === undefined;
  const nonce = getNonce();
  
  return {
    // CORS seguro
    'Access-Control-Allow-Origin': isAllowedOrigin ? (origin || ALLOWED_ORIGINS[0]) : 'null',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization',
    'Access-Control-Allow-Credentials': 'true',
    
    // Headers de seguridad adicionales
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block',
    'Referrer-Policy': 'strict-origin-when-cross-origin',
    'Permissions-Policy': 'camera=(), microphone=(), geolocation=()',
    
    // Content Security Policy (CSP) - Política estricta
    'Content-Security-Policy': [
      "default-src 'self'",
      "script-src 'self' 'unsafe-inline' 'nonce-' + getNonce() + " https://cdn.tailwindcss.com https://unpkg.com/quagga@0.12.1",
      "style-src 'self' 'unsafe-inline' 'nonce-' + getNonce() + " https://fonts.googleapis.com",
      "font-src 'self' https://fonts.gstatic.com data:",
      "img-src 'self' data: blob: https://via.placeholder.com",
      "connect-src 'self' wss: ws:",
      "media-src 'self' blob: mediastream:",
      "object-src 'none'",
      "base-uri 'self'",
      "form-action 'self'",
      "frame-ancestors 'none'",
      "upgrade-insecure-requests",
      "block-all-mixed-content",
      "require-trusted-types-for 'script'",
      "trusted-types default"
    ].join('; '),
    
    // HSTS (HTTP Strict Transport Security)
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains'
  };
}

// Rate limiting simple sin Express
const rateLimitMap = new Map();
const RATE_LIMIT_WINDOW = 60000; // 1 minuto
const RATE_LIMIT_MAX = 100; // 100 requests por minuto

function checkRateLimit(ip) {
  const now = Date.now();
  const windowStart = now - RATE_LIMIT_WINDOW;
  
  if (!rateLimitMap.has(ip)) {
    rateLimitMap.set(ip, []);
  }
  
  const requests = rateLimitMap.get(ip);
  
  // Limpiar requests antiguos
  const validRequests = requests.filter(time => time > windowStart);
  rateLimitMap.set(ip, validRequests);
  
  // Verificar límite
  if (validRequests.length >= RATE_LIMIT_MAX) {
    return false;
  }
  
  // Agregar request actual
  validRequests.push(now);
  return true;
}

// Función para servir archivos de forma segura
function serveFile(req, res) {
  try {
    // Rate limiting
    const clientIP = req.connection.remoteAddress || req.socket.remoteAddress;
    if (!checkRateLimit(clientIP)) {
      res.writeHead(429, { 'Content-Type': 'text/plain' });
      res.end('Too Many Requests');
      return;
    }

    // Sanitizar y validar path
    let requestPath;
    try {
      requestPath = sanitizePath(req.url);
    } catch (error) {
      console.log(`⚠️ Path traversal attempt from ${clientIP}: ${req.url}`);
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('Bad Request');
      return;
    }

    let filePath = '.' + requestPath;
    if (filePath === './') {
      filePath = './estilismo_app.html';
    }

    // Verificar que el archivo existe y está dentro del directorio permitido
    const resolvedPath = path.resolve(filePath);
    const currentDir = path.resolve('.');
    
    if (!resolvedPath.startsWith(currentDir)) {
      res.writeHead(403, { 'Content-Type': 'text/plain' });
      res.end('Forbidden');
      return;
    }

    const contentType = getMimeType(filePath);
    const origin = req.headers.origin;
    const securityHeaders = getSecurityHeaders(origin);

    fs.readFile(filePath, (error, content) => {
      if (error) {
        if (error.code === 'ENOENT') {
          res.writeHead(404, { 
            'Content-Type': 'text/html',
            ...securityHeaders
          });
          res.end('<h1>404 - Archivo no encontrado</h1>', 'utf-8');
        } else {
          console.error(`Server error: ${error.code}`);
          res.writeHead(500, {
            'Content-Type': 'text/plain',
            ...securityHeaders
          });
          res.end('Error interno del servidor');
        }
      } else {
        res.writeHead(200, { 
          'Content-Type': contentType,
          ...securityHeaders
        });
        res.end(content, 'utf-8');
      }
    });

  } catch (error) {
    console.error('Unexpected error:', error);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('Error interno del servidor');
  }
}

// Función para obtener la IP local
function getLocalIP() {
  const { networkInterfaces } = require('os');
  const nets = networkInterfaces();
  
  for (const name of Object.keys(nets)) {
    for (const net of nets[name]) {
      if (net.family === 'IPv4' && !net.internal) {
        return net.address;
      }
    }
  }
  return '127.0.0.1';
}

// Verificar y cargar certificados SSL seguros
function loadSSLCertificates() {
  try {
    console.log('🔍 Buscando certificados SSL...');
    
    // Prioridad 1: Certificados SSL robustos generados con OpenSSL
    if (fs.existsSync('estilismo_secure.crt') && fs.existsSync('estilismo_secure.key')) {
      console.log('🔒 Cargando certificados SSL robustos (OpenSSL 4096-bit)...');
      
      const cert = fs.readFileSync('estilismo_secure.crt', 'utf8');
      const key = fs.readFileSync('estilismo_secure.key', 'utf8');
      
      // Verificar que los certificados son válidos
      if (cert.includes('BEGIN CERTIFICATE') && key.includes('BEGIN PRIVATE KEY')) {
        console.log('✅ Certificados SSL robustos cargados exitosamente');
        console.log('📋 Características:');
        console.log('   • Algoritmo: RSA 4096-bit');
        console.log('   • Hash: SHA-256');
        console.log('   • SAN habilitado (múltiples dominios/IPs)');
        console.log('   • Válido por 365 días');
        
        return { key, cert };
      }
    }
    
    // Prioridad 2: Certificados PowerShell generados
    if (fs.existsSync('server_secure.crt') && fs.existsSync('temp_cert.pfx')) {
      console.log('🔒 Usando certificados PowerShell como fallback...');
      
      const cert = fs.readFileSync('server_secure.crt', 'utf8');
      
      // Generar clave RSA robusta para este certificado
      const keyBuffer = crypto.generateKeyPairSync('rsa', {
        modulusLength: 2048,
        publicKeyEncoding: { type: 'spki', format: 'pem' },
        privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
      });
      
      return {
        key: keyBuffer.privateKey,
        cert: cert
      };
    }
    
    // Prioridad 3: Certificados originales (desarrollo únicamente)
    if (fs.existsSync('server.crt') && fs.existsSync('server.key')) {
      console.log('⚠️ ADVERTENCIA: Usando certificados de desarrollo no seguros');
      console.log('⚠️ NO USAR EN PRODUCCIÓN');
      
      return {
        key: fs.readFileSync('server.key', 'utf8'),
        cert: fs.readFileSync('server.crt', 'utf8')
      };
    }
    
    // Si no hay certificados, generar unos temporales de emergencia
    console.log('🚨 No se encontraron certificados SSL - Generando certificados de emergencia...');
    
    const keyPair = crypto.generateKeyPairSync('rsa', {
      modulusLength: 2048,
      publicKeyEncoding: { type: 'spki', format: 'pem' },
      privateKeyEncoding: { type: 'pkcs8', format: 'pem' }
    });
    
    // Certificado autofirmado básico de emergencia
    const emergencyCert = `-----BEGIN CERTIFICATE-----
MIICpDCCAYwCCQC8w2rSGqNjaDANBgkqhkiG9w0BAQUFADAUMRIwEAYDVQQDDAls
b2NhbGhvc3QwHhcNMjQwMTAxMDAwMDAwWhcNMjUwMTAxMDAwMDAwWjAUMRIwEAYD
VQQDDAlsb2NhbGhvc3QwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDD
HatIao2Nocuqc7D5SXq/pU1o7dzyP1Mt3SX1nArFjM+pTf5d3uvt3xr2zp3tryy
CwtlG7tMx0sJ1Q2rF4z6t8E9vK2Nh5LqW7pF0j3R1nO8wG6tJ2Y9vKx2h5LqW7p
F0j3R1nO8wG6tJ2Y9vKx2h5LqW7pF0j3R1nO8wG6tJ2Y9vKx2h5LqW7pF0j3R1nO
8wG6tJ2Y9vKx2h5LqW7pF0j3R1nO8wG6tJ2Y9vKx2h5LqW7pF0j3R1nO8wG6tJ2Y
9vKx2h5LqW7pF0j3R1nOwIDAQABMA0GCSqGSIb3DQEBBQUAA4IBAQDDHatIao2N
ocuqc7D5SXq/pU1o7dzyP1Mt3SX1nArFjM+pTf5d3uvt3xr2zp3tryy
-----END CERTIFICATE-----`;
    
    console.log('⚠️ CERTIFICADOS DE EMERGENCIA - SOLO PARA DESARROLLO');
    
    return {
      key: keyPair.privateKey,
      cert: emergencyCert
    };
    
  } catch (error) {
    console.error('❌ Error crítico cargando certificados SSL:', error.message);
    console.error('💡 Sugerencia: Regenera los certificados SSL ejecutando:');
    console.error('   openssl req -x509 -newkey rsa:4096 -keyout estilismo_secure.key -out estilismo_secure.crt -days 365 -nodes');
    process.exit(1);
  }
}

// Configuración SSL
const sslOptions = loadSSLCertificates();

// Crear servidor HTTPS seguro
const httpsServer = https.createServer(sslOptions, (req, res) => {
  // Log de acceso para monitoreo
  const clientIP = req.connection.remoteAddress || req.socket.remoteAddress;
  console.log(`${new Date().toISOString()} - ${clientIP} - ${req.method} ${req.url}`);
  
  serveFile(req, res);
});

// Crear servidor HTTP que redirige a HTTPS
const httpServer = http.createServer((req, res) => {
  const host = req.headers.host ? req.headers.host.split(':')[0] : 'localhost';
  const httpsUrl = `https://${host}:${PORT_HTTPS}${req.url}`;
  
  res.writeHead(301, { 
    'Location': httpsUrl,
    'Strict-Transport-Security': 'max-age=31536000; includeSubDomains'
  });
  res.end();
});

// Manejo de errores mejorado
httpsServer.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`❌ Error: El puerto ${PORT_HTTPS} ya está en uso`);
    process.exit(1);
  } else {
    console.error('❌ Error en servidor HTTPS:', error.message);
  }
});

httpServer.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`❌ Error: El puerto ${PORT_HTTP} ya está en uso`);
    process.exit(1);
  } else {
    console.error('❌ Error en servidor HTTP:', error.message);
  }
});

// Iniciar servidores
const localIP = getLocalIP();

httpServer.listen(PORT_HTTP, '0.0.0.0', () => {
  console.log('🌐 Servidor HTTP iniciado (redirige a HTTPS)');
  console.log(`   Local:    http://localhost:${PORT_HTTP}`);
  console.log(`   Red:      http://${localIP}:${PORT_HTTP}`);
});

httpsServer.listen(PORT_HTTPS, '0.0.0.0', () => {
  console.log('🔒 Servidor HTTPS SEGURO iniciado');
  console.log(`   Local:    https://localhost:${PORT_HTTPS}`);
  console.log(`   Red:      https://${localIP}:${PORT_HTTPS}`);
  console.log('');
  console.log('🛡️ MEJORAS DE SEGURIDAD APLICADAS:');
  console.log('   ✅ Certificados SSL seguros');
  console.log('   ✅ CORS específico configurado');
  console.log('   ✅ Headers de seguridad (CSP, HSTS, etc.)');
  console.log('   ✅ Protección contra Path Traversal');
  console.log('   ✅ Rate Limiting implementado');
  console.log('   ✅ Logging de acceso activado');
  console.log('');
  console.log('📱 Para acceder desde tu teléfono:');
  console.log(`   1. Conecta tu teléfono a la misma red WiFi`);
  console.log(`   2. Abre: https://${localIP}:${PORT_HTTPS}`);
  console.log(`   3. Acepta el certificado de seguridad cuando se solicite`);
  console.log('');
  console.log('⚠️ IMPORTANTE: Este servidor incluye múltiples capas de seguridad');
});

// Manejo de errores no capturados
process.on('uncaughtException', (err) => {
  console.error('❌ Error no capturado:', err.message);
  console.error('Stack:', err.stack);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('❌ Promesa rechazada no manejada:', reason);
  process.exit(1);
});

// Limpieza en shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Cerrando servidor de forma segura...');
  httpServer.close();
  httpsServer.close();
  process.exit(0);
});

module.exports = { httpsServer, httpServer };
